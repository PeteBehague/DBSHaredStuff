import { useState } from 'react';
import './App.css';
import PriceEntryField from './components/PriceEntryField';
import VatRateField from './components/VatRateField';
import VatToPay from './components/VatToPay';


function App() {
  const [netPrice, setNetPrice] = useState(0.0);
  const [grossPrice, setGrossPrice] = useState(0.0);
  const [vatToPay, setVatToPay] = useState(0.0);
  //const [vatRateText, setVatRateText] = useState(20.0);
  const [vatRate, setVatRate] = useState(20.0);



  const handleNetPriceChange = (price) => {
    const gross_price = Math.round(price * ((vatRate / 100) + 1));
    setNetPrice(price);
    setGrossPrice(gross_price);
    // calc vat to pay and set state
    setVatToPay(gross_price - price);
  };

  const handleGrossPriceChange = (price) => {
   
    const net_price = Math.round(price / ((vatRate / 100) + 1));
    setNetPrice(net_price);
    setGrossPrice(price);
    // calc vat to pay and set state
    setVatToPay(price - net_price);
  };

  const handleVatRateChanged = (rate) => {
    setVatRate(rate);
    handleNetPriceChange(netPrice);
  };

  const updatePrices = () => {
    handleNetPriceChange(netPrice);
  };

  return (
    <div className="App">
        <VatRateField vatRateChanged={handleVatRateChanged} value={vatRate} updatePrices={updatePrices} />
        <PriceEntryField label="Prive excl VAT" valueChanged={handleNetPriceChange} value={netPrice === 0.0 ? "" : netPrice} />
        <VatToPay vat={vatToPay} />
        <PriceEntryField label="Prive incl VAT" valueChanged={handleGrossPriceChange} value={grossPrice === 0.0 ? "" : grossPrice}/>
    </div>
  );
}

export default App;
