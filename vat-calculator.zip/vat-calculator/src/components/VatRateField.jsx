import React, { useEffect } from "react";
//const rates = `http://localhost:4000/vatRates`;
import data from './../vatRates.json';


const VatRateField = (props) => {
    const { updatePrices } = props;

    useEffect(() => {
        updatePrices();
    }, [props.value, updatePrices]);

       return (
        <div>
            VAT Rate:
            <select value={props.value} onChange={(event) => { props.vatRateChanged(event.target.value); }}>
                {
                    data.map((data) => (
                        <option key={data.id} value={data.rate} >
                            {console.log(data.id)}
                            {data.text}
                        </option>
                    ))
                } 
            </select>          
                    {/* <div className={props.customstyle}>
            VAT Rate: &nbsp;
            <select value={props.value} onChange={(event) => { props.vatRateChanged(+event.target.value); }}>
                <option value="20">20%</option>
                <option value="15">15%</option>
                <option value="12.5">12.5%</option>
                <option value="0">Exempt</option>
            </select>
        </div> */}
        </div>
    );
}

export default VatRateField