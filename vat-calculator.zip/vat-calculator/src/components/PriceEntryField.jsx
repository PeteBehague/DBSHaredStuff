import React from "react";

const PriceEntryField = (props) => {

    return (
        <div>
            {props.label}
            <input type="number" value={props.value} onChange={(event) => {props.valueChanged(event.target.value); }} />
        </div>
    )
}

export default PriceEntryField