import React from "react";

const VatToPay = (props) => {
    return (
        <div>
            Vat To Pay: {props.vat}
        </div>
    );
}

export default VatToPay;